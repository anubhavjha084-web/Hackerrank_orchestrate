#!/usr/bin/env python3
"""Buy or Wait? solution implementation (baseline).

This script reads the dataset CSV files, performs a simple heuristic decision
for each request, and writes `output.csv` with the required columns.

Heuristic (baseline):
- Use the user's available balance and minimum balance from `financial_profiles.csv`.
- Compute `amount_safe_to_pay` as the maximum amount that can be paid today
  without dropping below the minimum balance.
- If this amount covers the whole requested amount, the request is `affordable_now`
  and we recommend `full_payment`.
- Otherwise, if the request allows partial payment, we recommend a `partial_payment`
  plan with two payments: the safe amount today and the remainder on the request
  date (as a placeholder for the earliest safe full‑payment date).
- If partial payment is not allowed, we mark the request as `not_affordable`
  and `not_recommended`.
- Spending changes, installments and waiting are not modeled in this baseline.

The output follows the exact column order required by the challenge.
"""
import csv
import os
from datetime import datetime

DATASET_DIR = os.path.join(os.path.dirname(__file__), "..", "dataset")
OUTPUT_PATH = os.path.join(DATASET_DIR, "output.csv")

def load_profiles():
    profiles = {}
    path = os.path.join(DATASET_DIR, "financial_profiles.csv")
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            user_id = row["user_id"]
            profiles[user_id] = {
                "balance": float(row.get("available_balance", "0")),
                "min_balance": float(row.get("minimum_balance_to_keep", "0")),
                "allows_partial": row.get("allows_partial_payment", "false").lower() == "true",
            }
    return profiles

def load_requests():
    requests = []
    path = os.path.join(DATASET_DIR, "requests.csv")
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            requests.append(row)
    return requests

def write_output(rows):
    fieldnames = [
        "request_id",
        "amount_safe_to_pay",
        "affordability_status",
        "recommended_payment_method",
        "payment_plan",
        "earliest_date_for_full_payment",
        "spending_changes_needed",
        "decision_explanation",
    ]
    with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

def main():
    profiles = load_profiles()
    requests = load_requests()
    out_rows = []
    for req in requests:
        user_id = req["user_id"]
        profile = profiles.get(user_id, {"balance": 0, "min_balance": 0, "allows_partial": False})
        balance = profile["balance"]
        min_bal = profile["min_balance"]
        requested = float(req.get("requested_amount", "0"))
        allows_partial = req.get("allows_partial_payment", "false").lower() == "true"

        # Compute safe amount today
        amount_safe = max(0.0, balance - min_bal)
        amount_safe = min(amount_safe, requested)
        amount_safe_str = f"{amount_safe:.2f}".rstrip('0').rstrip('.') if '.' in f"{amount_safe:.2f}" else f"{int(amount_safe)}"

        if amount_safe >= requested:
            status = "affordable_now"
            method = "full_payment"
            plan = "none"
            earliest = req["request_date"]
            changes = "none"
            explanation = "Full amount can be safely paid today without breaching minimum balance."
        elif allows_partial and amount_safe > 0:
            status = "affordable_with_plan"
            method = "partial_payment"
            remainder = requested - amount_safe
            # Placeholder: assume remainder can be paid on the desired completion date
            plan = f"{req['request_date']}:{amount_safe_str}|{req['desired_completion_date']}:{remainder:.2f}".replace('.00', '')
            earliest = req["desired_completion_date"]
            changes = "none"
            explanation = "Partial payment today and remainder later stay within balance constraints."
        else:
            status = "not_affordable"
            method = "not_recommended"
            plan = "none"
            earliest = ""
            changes = "none"
            explanation = "Insufficient balance to cover request safely."

        out_rows.append({
            "request_id": req["request_id"],
            "amount_safe_to_pay": amount_safe_str,
            "affordability_status": status,
            "recommended_payment_method": method,
            "payment_plan": plan,
            "earliest_date_for_full_payment": earliest,
            "spending_changes_needed": changes,
            "decision_explanation": explanation,
        })
    write_output(out_rows)

if __name__ == "__main__":
    main()
